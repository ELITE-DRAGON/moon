# JumpPng (Jpeg To PNG Converter)

> Hi, im Alireza Fazeli and i made this application with love 😊❤
this application is very simple and i made this application to make easy your life.
so pleas follow my linkedin and github ❤ :
    > https://linkedin.com/in/alirezafazeli
    > https://github.com/alirezafazeli8
---
## What you need ?

- first of all you need two path. first is your JPEG file path.

    - for example : "D:\\3- photo\yakuza.jpg"
    - second is your destination path. 
    for example : "C:\Users\Alireza\Desktop"

    > just this 💥. follow me and learn the commands.
---
- -c , --convert :
    with one of these commands you can convert your JPEG file to PNG.
    for example : python JpegToPngConverter.py -c "D:\\3- photo\yakuza.jpg" "C:\Users\Alireza\Desktop"
    
- -h , --help : 
    now you are in fucking help 😂❤
    
- -v : 
    you can see where we are. maybe later i or with your help , i develop more this app.

> Enjoy it . Alireza Fazeli ❤
    